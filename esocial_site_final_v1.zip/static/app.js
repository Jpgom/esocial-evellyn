
const relFilesPicker = document.getElementById('relFilesPicker');
const relFolderPicker = document.getElementById('relFolderPicker');
const hiddenRelFiles = document.getElementById('hiddenRelFiles');
const fileListBody = document.getElementById('fileListBody');
const fileCount = document.getElementById('fileCount');
const clearAllBtn = document.getElementById('clearAllBtn');
const uploadForm = document.getElementById('uploadForm');
const selectionSummary = document.getElementById('selectionSummary');
const loadingOverlay = document.getElementById('loadingOverlay');
const baseFileInput = document.getElementById('baseFile');
const baseSheetSelect = document.getElementById('baseSheetSelect');

let selectedFiles = [];

function hideLoading(){ if(!loadingOverlay) return; loadingOverlay.classList.remove('is-visible'); loadingOverlay.classList.add('is-hidden'); }
function showLoading(){ if(!loadingOverlay) return; loadingOverlay.classList.remove('is-hidden'); loadingOverlay.classList.add('is-visible'); }

function setSheetOptions(options){
  baseSheetSelect.innerHTML = "";
  options.forEach(item => {
    const option = document.createElement('option');
    option.value = item.value;
    option.textContent = item.label;
    baseSheetSelect.appendChild(option);
  });
}

async function loadBaseSheets(){
  const file = baseFileInput.files[0];
  if(!file){
    setSheetOptions([{value:"", label:"Carregue a planilha base primeiro"}]);
    return;
  }
  const formData = new FormData();
  formData.append('base_file', file);
  setSheetOptions([{value:"", label:"Lendo abas da planilha..."}]);
  try{
    const response = await fetch('/abas-base', {method:'POST', body: formData});
    const data = await response.json();
    if(!data.ok){
      setSheetOptions([{value:"", label:"Não foi possível ler as abas"}]);
      return;
    }
    const sheets = data.sheets || [];
    if(sheets.length <= 1){
      setSheetOptions([{value: sheets[0] || "", label: sheets[0] || "Planilha principal"}]);
      return;
    }
    setSheetOptions([{value:"", label:"Selecione a aba do mês"}, ...sheets.map(sheet => ({value:sheet, label:sheet}))]);
  }catch(e){
    setSheetOptions([{value:"", label:"Erro ao carregar abas"}]);
  }
}

function isValidRelFile(file){ return ['.xls','.xlsx','.html','.htm'].some(ext => file.name.toLowerCase().endsWith(ext)); }
function buildKey(file){ return `${file.name}__${file.size}__${file.lastModified}`; }
function syncHiddenInput(){ const dt = new DataTransfer(); selectedFiles.forEach(item => dt.items.add(item.file)); hiddenRelFiles.files = dt.files; }

function updateSummary(){
  const total = selectedFiles.length;
  fileCount.textContent = `${total} arquivo(s)`;
  selectionSummary.textContent = total === 0 ? 'Nenhum arquivo selecionado.' : `${total} arquivo(s) prontos para processamento.`;
}

function renderFileList(){
  fileListBody.innerHTML = '';
  if(selectedFiles.length === 0){
    fileListBody.innerHTML = `<tr class="empty-row"><td colspan="3">Nenhum RELFUNCGERAL selecionado.</td></tr>`;
    updateSummary(); syncHiddenInput(); return;
  }
  selectedFiles.forEach((item, index) => {
    const tr = document.createElement('tr');
    tr.innerHTML = `<td>${item.file.name}</td><td>${item.source}</td><td><button type="button" class="btn btn--danger remove-btn" data-index="${index}">Retirar</button></td>`;
    fileListBody.appendChild(tr);
  });
  document.querySelectorAll('.remove-btn').forEach(btn => {
    btn.addEventListener('click', () => { selectedFiles.splice(Number(btn.dataset.index), 1); renderFileList(); });
  });
  updateSummary(); syncHiddenInput();
}

function addFiles(fileList, sourceLabel){
  const existingKeys = new Set(selectedFiles.map(item => buildKey(item.file)));
  Array.from(fileList).forEach(file => {
    if(!isValidRelFile(file)) return;
    const key = buildKey(file);
    if(existingKeys.has(key)) return;
    const source = file.webkitRelativePath ? file.webkitRelativePath : sourceLabel;
    selectedFiles.push({file, source});
    existingKeys.add(key);
  });
  renderFileList();
}

if(baseFileInput) baseFileInput.addEventListener('change', loadBaseSheets);
if(relFilesPicker) relFilesPicker.addEventListener('change', e => { addFiles(e.target.files, 'Seleção individual'); e.target.value=''; });
if(relFolderPicker) relFolderPicker.addEventListener('change', e => { addFiles(e.target.files, 'Pasta'); e.target.value=''; });
if(clearAllBtn) clearAllBtn.addEventListener('click', () => { selectedFiles = []; renderFileList(); hideLoading(); });

if(uploadForm){
  uploadForm.addEventListener('submit', e => {
    if(selectedFiles.length === 0){
      e.preventDefault(); hideLoading(); alert('Selecione pelo menos um arquivo RELFUNCGERAL.'); return;
    }
    const optionsCount = baseSheetSelect.options.length;
    const selectedSheet = baseSheetSelect.value;
    if(optionsCount > 1 && !selectedSheet){
      e.preventDefault(); alert('Selecione a aba da planilha base.'); return;
    }
    syncHiddenInput(); showLoading();
  });
}

window.addEventListener('load', hideLoading);
window.addEventListener('pageshow', hideLoading);
renderFileList();
hideLoading();
